from django.shortcuts import render
from django.views.decorators import csrf
import os,datetime
import pandas as pd
import numpy as np
import time
import sys
from django.http import HttpResponse,JsonResponse
import collections
import pymysql
import json,random,string
import seaborn as sns; sns.set(color_codes=True)
from sklearn.decomposition import PCA
import re
from transcriptome.run_deg import DESEQ2Runner , EDGERRunner

def differential_expression_analysis(request):
    try:
        if request.method == 'POST':
            # 1. 確保 body 有內容
            if not request.body:
                return JsonResponse({'error': 'Empty request body'}, status=400)

            # 2. 解析 JSON (這步會把 null 轉成 None)
            data = json.loads(request.body.decode('utf-8'))
            species = data.get('species')
            print("Species:", species)
            method = data.get('method')
            size_ = data.get('size')
            meta_data = data.get('all_columns_map', [])
            print("Meta Columns:", meta_data)
            print("Method: {0}, Size: {1}.".format(method, size_))
            if method == 'edgeR':
                runner = EDGERRunner(species, meta_data)
            else:
                runner = DESEQ2Runner(species, meta_data, size_)
            cache_result = runner.check_cache()
            if cache_result['exists']:
                print("--- 找到快取，直接回傳 ---")
                return JsonResponse({
                    'status': 'success',
                    'volcano_path': cache_result['volcano_path'],
                    'ma_path': cache_result['ma_path'],
                    'jobID': runner.job_id,
                    'cached': True
                })
            print("--- 無快取，製作表格並執行分析中... ---")	
            rows = []
            for item in meta_data:
                col_name = item['col']
                status = item['stat']

                if status == 'control':
                    rows.append({'columns': col_name, 'condition': 'A'})
                elif status == 'comparison':
                    rows.append({'columns': col_name, 'condition': 'B'})
            df = pd.DataFrame(rows, columns=['columns', 'condition'])
            print(df['columns'].tolist())  #供count table選擇欄位做使用
            # 測試：印出 DataFrame 看看結果
            print("--- Generated Design Matrix ---")
            print(df)
            df.to_csv('/Orchid/Data/DGA/temp_meta.csv', index=False)
            #讀取表現量表格，並篩選必要欄位
            df_count = pd.read_csv('/Orchid/Data/DGA/{0}_counts.csv'.format(species))
            keep_cols = ['id'] + df['columns'].dropna().tolist()
            # 避免 keep_cols 有些不在 count table 裡造成 KeyError #keep_existing = [c for c in keep_cols if c in df_count.columns]
            df_count_tmp = df_count[keep_cols]
            df_count_tmp.to_csv('/Orchid/Data/DGA/temp_count.csv', index=False)
            '''
            輸入：
            /Orchid/Data/DGA/temp_count.csv
            /Orchid/Data/DGA/temp_meta.csv
            method 
            若兩個組別各選一個 則作edgeR -exact Test
            若選擇多個樣本 則使用Deseq2 並且根據樣本選擇最少邊 進行size輸入

            例如:image_path = '/orchidbase7_static/img/DEG/Vsh_MA.png'
            跑差異分析程式碼
            獲得結果圖片路徑
            '''
            if method == 'edgeR':
                analysis_results = runner.run_edgeR()
                return JsonResponse({
                    'status': 'success',
                    'volcano_path': analysis_results['volcano_path'],
                    'ma_path': analysis_results['ma_path'],
                    'jobID': runner.job_id
                })
            else:
                analysis_results = runner.run_deseq2()
                return JsonResponse({
                    'status': 'success',
                    'volcano_path': analysis_results['volcano_path'],
                    'ma_path': analysis_results['ma_path'],
                    'jobID': runner.job_id
                })
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)
